package com.example.gas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
