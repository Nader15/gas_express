const String IMAGE_ROOT = "assets/images/";
const String APP_LOGO = IMAGE_ROOT + "AppLogo.jpg";
